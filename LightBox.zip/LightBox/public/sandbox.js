var centraldiv = null;
var canvas = new fabric.Canvas("sandbox");
var center = {'x': canvas.width/2, 'y': canvas.height/2};

var qw = canvas.width/4;
var qh = (canvas.height-(canvas.height/10))/2;
var q1 = {'x':qw - (qw*0.5), 'y':qh};
var q2 = {'x':(qw*2)-(qw*0.5), 'y':qh};
var q3 = {'x':(qw*3)-(qw*0.5), 'y':qh};
var q4 = {'x':(qw*4)-(qw*0.5), 'y':qh};

var imgs = [];
var get = true;

function InIt()
{
	centraldiv = document.getElementByID("central");
}

setInterval(getImage,1000);

function getImage()
{
	if(get)
	{
		fabric.Image.fromURL('http://upload.wikimedia.org/wikipedia/commons/thumb/0/00/Crab_Nebula.jpg/1024px-Crab_Nebula.jpg', function(oImg)
		{
			//oImg.scale(0.05);
			//imgs.push(oImg);

			AddToTray(oImg);
		});

		if(imgs.length >= 10)
		{
			get = false;
			//ImageDisplay();
		}
	}
}

function AddToTray(img)
{
	var work = new Work(imgs.length-1, img);
	imgs.push(work);
}

//Work Class/////////////////////////////////////////////////////////////////////////////

function Work(_index, _img)
{
	this.ix = _index;
	this.dur = 750;//animation duration

	this.timg = _img; //little image
	this.tw = canvas.width/20;
	this.th = 0;
	this.tx = (canvas.width/2)-(this.tw/2);
	this.ty = 500;//canvas.height; //bottom

	this.tinit();

	this.bimg = _img; //big image
	this.bwo = _img.getWidth(); 
	this.bho = _img.getHeight();
	this.bx = (canvas.width/2)-(this.bw/2);
	this.by = (canvas.height/2)-(this.bh/2);
	
	//this.binit();
}

Work.prototype.tinit = function() //little image instatiation
{
	this.timg.scaleToWidth(this.tw);
	this.th = this.timg.getHeight();

	this.timg.left = this.tx;
	this.timg.bottom = this.ty+this.th;
	this.timg.hasBorders = false;
	//this.timg.hasControls = false;
	//this.timg.lockMovementY = true;

	this.tada();
}

Work.prototype.tada = function()
{
	console.log('tada');

	for(var i in imgs)
	{
		imgs[i].trayshift();
	}

	canvas.add(this.timg); //add little image to canvas immediately

	this.timg.animate('bottom', '-=100', { //this.th
		onChange: canvas.renderAll.bind(canvas),
		duration: this.dur,
		easing: fabric.util.ease.easeOutBounce
	});
}

Work.prototype.binit = function() //big image instatiation
{
	if(this.bh > this.bw)
	{
		var h = (canvas.height-this.by)*2;
		this.bimg.scaleToHeight(h);
		this.bh = h;
		this.bw = this.bimg.getWidth(); //width refers to original width, getWidth() returns current
	}
	else
	{
		var w = (canvas.width - this.bx)*2;
		this.bimg.scaleToWidth(w);
		this.bw = w;
		this.bh = this.bimg.getHeight(); //height refers to original height, getHeight() returns current
	}
		this.bimg.left = this.bx;
		this.bimg.top = this.by;
		this.bimg.hasBorders = false;
		this.bimg.hasControls = false;
		this.bimg.lockMovementX = true;
		this.bimg.lockMovementY = true;

		//incorporate buttons - close + add to tray
}

Work.prototype.trayshift = function()
{
	if(this.tx < center.x)
	{
		this.timg.animate('left', '-='+this.tw, {
			onChange: canvas.renderAll.bind(canvas),
			duration: this.dur,
			easing: fabric.util.ease.easeOutBounce
			});
	}
	else
	{
		this.timg.animate('left', '+='+this.tw, {
			onChange: canvas.renderAll.bind(canvas),
			duration: this.dur,
			easing: fabric.util.ease.easeOutBounce
			});
	}
}

//approach w/ div

//canvas.on('mouse:down',...)

//canvas.add(Img);